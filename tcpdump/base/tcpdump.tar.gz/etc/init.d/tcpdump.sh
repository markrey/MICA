#! /bin/sh

mkdir /tmp/sdcard
mount /dev/mmcblk1p1 /tmp/sdcard

/usr/sbin/tcpdump -i br0 -A -p -n -nn -G 3600 -w /tmp/sdcard/tcpdump_br0_%Y%m%d%H.cap &
/usr/sbin/tcpdump -i br1 -A -p -n -nn -G 3600 -w /tmp/sdcard/tcpdump_br1_%Y%m%d%H.cap &

